const STORAGE_KEY = "radiant_lang";

function setDirAndLang(lang){
  const html = document.documentElement;
  html.setAttribute("data-lang", lang);
  html.lang = lang === "ar" ? "ar" : "en";
  html.dir = lang === "ar" ? "rtl" : "ltr";
}

async function loadContent(){
  const lang = localStorage.getItem(STORAGE_KEY) || "en";
  setDirAndLang(lang);

  const file = lang === "ar" ? "/content/site-ar.json" : "/content/site-en.json";

  try{
    const res = await fetch(file, { cache: "no-store" });
    const data = await res.json();

    document.querySelectorAll("[data-key]").forEach(el => {
      const key = el.getAttribute("data-key");
      if (data[key] !== undefined && data[key] !== null) el.textContent = data[key];
    });

    // contact links
    const email = data.email || "your@email.com";
    const phone = data.phone || "+966000000000";
    const waNumber = phone.replace(/[^\d]/g,"");

    const emailLink = document.getElementById("emailLink");
    const phoneLink = document.getElementById("phoneLink");
    const waFloat = document.getElementById("waFloat");

    if (emailLink){
      emailLink.textContent = email;
      emailLink.href = `mailto:${email}`;
    }
    if (phoneLink){
      phoneLink.textContent = phone;
      phoneLink.href = `https://wa.me/${waNumber}`;
    }
    if (waFloat){
      waFloat.href = `https://wa.me/${waNumber}`;
    }

    // PDF profile link
    const profileUrl = data.profilePdfUrl || "/assets/uploads/company-profile.pdf";
    document.querySelectorAll("#profileLink").forEach(a => a.href = profileUrl);

    // language buttons text
    const btnText = lang === "ar" ? "EN" : "AR";
    document.getElementById("langToggle")?.textContent = btnText;
    document.getElementById("langToggleMobile")?.textContent = btnText;

    document.getElementById("year")?.textContent = new Date().getFullYear();
  } catch (e){
    console.warn("Content load failed:", e);
    document.getElementById("year")?.textContent = new Date().getFullYear();
  }
}

function toggleLang(){
  const current = localStorage.getItem(STORAGE_KEY) || "en";
  const next = current === "en" ? "ar" : "en";
  localStorage.setItem(STORAGE_KEY, next);
  loadContent();
}

// Mobile nav
document.getElementById("burger")?.addEventListener("click", () => {
  const nav = document.getElementById("mobileNav");
  if (!nav) return;
  nav.style.display = nav.style.display === "flex" ? "none" : "flex";
});

document.getElementById("langToggle")?.addEventListener("click", toggleLang);
document.getElementById("langToggleMobile")?.addEventListener("click", toggleLang);

loadContent();
