Put your company-profile.pdf here as: company-profile.pdf
